#include "engine.hpp"
#include <iostream>
#include <thread>
#include <glm/glm.hpp>
#include "shaderFactory.hpp"
#include "sceneReader.hpp"

Engine::Engine(GLFWwindow* window, ConfigReader* configReader)
    : window(window), configReader(configReader)
{
    previousTime = std::chrono::high_resolution_clock::now();

    camera = std::make_unique<Camera>(window, configReader->getCameraSettings());
    defaultShaderProgram = std::make_unique<ShaderProgram>();
    defaultShaderProgram->observe(camera.get());

    auto vertexShader = ShaderFactory::createShader(GL_VERTEX_SHADER, configReader->getVertexShaderPath(), camera.get());
    auto fragmentShader = ShaderFactory::createShader(GL_FRAGMENT_SHADER, configReader->getFragmentShaderPath(), camera.get());

    defaultShaderProgram->attachShader(vertexShader);
    defaultShaderProgram->attachShader(fragmentShader);
    defaultShaderProgram->link();
}

void Engine::init(const std::string& scenePath)
{
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glfwGetWindowSize(window, &width, &height);

    SceneReader sceneReader(scenePath);
    Scene scene = sceneReader.readScene(defaultShaderProgram.get());
    drawableObjects = scene.getDrawableObjects();
    gameObjects = scene.getObjects();

    std::cout << "Init finished\n" << std::endl;
}

void Engine::run()
{

    while (!glfwWindowShouldClose(window))
    {
        double deltaTime = getDeltaTime();
        glfwPollEvents();

        if(input != nullptr)
            input->updateInput(deltaTime);
        else
            std::cout << "Input is nullptr!\n";

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        updateGameObjects(deltaTime);
        drawObjects();

        glfwSwapBuffers(window);
        
    }
}

void Engine::shutdown()
{
    input.reset();
    drawableObjects.clear();
    gameObjects.clear();
}

void Engine::updateGameObjects(float delta)
{
    for (auto& gObj : gameObjects)
        gObj->update(delta);
}

void Engine::drawObjects()
{
    for (auto& dObj : drawableObjects)
        dObj->draw();
}

double Engine::getDeltaTime()
{
    auto currentTime = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> deltaTime = currentTime - previousTime;
    previousTime = currentTime;
    return deltaTime.count();
}
