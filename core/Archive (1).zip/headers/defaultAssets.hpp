#ifndef DEFAULT_ASSETS_H
#define DEFAULT_ASSETS_H

#include <string>

using std::string;

struct DefaultAssets
{

    string defaultTexturePath = "/Engine/DefaultAssets/textures/defaultTexture.png";

};

#endif