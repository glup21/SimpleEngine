#ifndef IOBJECTFACTORY_H
#define IOBJECTFACTORY_H

class IObjectFactory
{
    //Declaratory abstract class, add functionaluty later, if needed.


};

#endif