#ifndef ILOADER_H
#define ILOADER_H

class ILoader
{

};

#endif 